s = 'Hello world!'
utf8 = s.encode('utf-8')
print(utf8)