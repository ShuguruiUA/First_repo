with open('.\Homework-06\\file.txt', 'r') as file:
    print(file.readlines())
